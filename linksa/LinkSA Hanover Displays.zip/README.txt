# HANOVER_LINKSA2025
ISSUED FOR LINK SA ROUTES AND SERVICES IN 2025.

THIS DATA IS PRIVATE AND IS TO BE SHARED WITH CONTROLLERS AND APPROPIATE PERSONNEL

No binaries were built due to possibly required editing.

ROUTE MAP:

Enter the number then the dest
Expresses = 16
alternatives (same route going to same place but different signage) = 5
routes with A at the end = 10

to routes = 1
from routes = 2

for example:
route 1201A would be (where a A is present)

1. Press R on the controller
2. Enter 1201
3. Press ENT
4. Press D on the controller
5. Enter 10
6. Press ENT

route 1100 would be (where there is only one direction)
1. Press R on the controller 
2. Enter 1100
3. Press ENT
4. Press D on the controller
5. Enter 1
6. Press ENT

route 1132 from mt. torrens would be (where two directions exist)

1. Press R on the controller 
2. Enter 1132
3. Press ENT
4. Press D on the controller
5. Enter 2
6. Press ENT

Please do not hesitate to email business@sockycat.net for help.